package entidades;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author JatnielMartínez
 */
public class Juego {
    
    private StringProperty colorFichasInvitado;
    private Partida partida;
    private Jugador jugadorInvitado;
    
    public Juego() {
        
    }
    
    public Juego(String colorFichasInvitado, Partida partida, Jugador jugadorInvitado) {
        this.colorFichasInvitado = new SimpleStringProperty(colorFichasInvitado);
        this.partida = partida;
        this.jugadorInvitado = jugadorInvitado;
    }
    
    public void setColorFichasInvitado(String colorFichasInvitado) {
        this.colorFichasInvitado = new SimpleStringProperty(colorFichasInvitado);
    }
    
    public void setPartida(Partida partida) {
        this.partida = partida;
    }
    
    public void setJugadorInvitado(Jugador jugadorInvitado) {
        this.jugadorInvitado = jugadorInvitado;
    }
    
    public String getColorFichasInvitado() {
        return colorFichasInvitado.get();
    }
    
    public Partida getPartida() {
        return partida;
    }
    
    public Jugador getJugadorInvitado() {
        return jugadorInvitado;
    }
    
    public StringProperty colorFichasInvitadoProperty() {
        return colorFichasInvitado;
    }
    
}
