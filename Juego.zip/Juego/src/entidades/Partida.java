package entidades;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author JatnielMartínez
 */
public class Partida {
    
    private StringProperty nombrePartida;
    private StringProperty disponibilidad;
    private IntegerProperty rondas;
    private StringProperty contrasena;
    private StringProperty colorFichasCreador;
    private Jugador creador;
    
    public Partida() {
        
    }
    
    public Partida(String nombrePartida, String disponibilidad, Integer rondas, 
            String contrasena, String colorFichasCreador, Jugador creador) {
        this.nombrePartida = new SimpleStringProperty(nombrePartida);
        this.disponibilidad = new SimpleStringProperty(disponibilidad);
        this.rondas = new SimpleIntegerProperty(rondas);
        this.contrasena = new SimpleStringProperty(contrasena);
        this.colorFichasCreador = new SimpleStringProperty(colorFichasCreador);
        this.creador = creador;
    }
    
    public void setNombrePartida(String nombrePartida) {
        this.nombrePartida = new SimpleStringProperty(nombrePartida);
    }
    
    public void setDisponibilidad(String disponibilidad) {
        this.disponibilidad = new SimpleStringProperty(disponibilidad);
    }
    
    public void setRondas(Integer rondas) {
        this.rondas = new SimpleIntegerProperty(rondas);
    }
    
    public void setContrasena(String contrasena) {
        this.contrasena = new SimpleStringProperty(contrasena);
    }
    
    public void setColorFichasCreador(String colorFichasCreador) {
        this.colorFichasCreador = new SimpleStringProperty(colorFichasCreador);
    }
    
    public void setCreador(Jugador creador) {
        this.creador = creador;
    }
    
    public String getNombrePartida() {
        return nombrePartida.get();
    }
    
    public String getDisponibilidad() {
        return disponibilidad.get();
    }
    
    public Integer getRondas() {
        return rondas.get();
    }
    
    public String getContrasena() {
        return contrasena.get();
    }
    
    public String getColorFichasCreador() {
        return colorFichasCreador.get();
    }
    
    public Jugador getCreador() {
        return creador;
    }
    
    public StringProperty nombrePartidaProperty() {
        return nombrePartida;
    }
    
    public StringProperty disponibilidadProperty() {
        return disponibilidad;
    }
    
    public IntegerProperty rondasProperty() {
        return rondas;
    }
    
    public StringProperty contrasenaProperty() {
        return contrasena;
    }
    
    public StringProperty colorFichasCreadorProperty() {
        return colorFichasCreador;
    }
    
}
