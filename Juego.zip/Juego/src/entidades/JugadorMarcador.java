package entidades;

/**
 *
 * @author JatnielMartínez
 */
public class JugadorMarcador {
    
    private Jugador jugador;
    private Marcador marcador;
    
    public JugadorMarcador() {
        
    }
    
    public JugadorMarcador(Jugador jugador, Marcador marcador) {
        this.jugador = jugador;
        this.marcador = marcador;
    }
    
    public void setJugador(Jugador jugador) {
        this.jugador = jugador;
    }
    
    public void setMarcador(Marcador marcador) {
        this.marcador = marcador;
    }
    
    public Jugador getJugador() {
        return jugador;
    }
    
    public Marcador getMarcador() {
        return marcador;
    }
    
}
