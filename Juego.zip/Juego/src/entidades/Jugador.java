package entidades;

import java.sql.Date;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

/**
 *
 * @author JatnielMartínez
 */
public class Jugador {
    
    private StringProperty nombreUsuario;
    private StringProperty contrasena;
    private StringProperty email;
    private Date fechaNac;
    
    public Jugador() {
        
    }
    
    public Jugador(String nombreUsuario, String contrasena, String email, Date fechaNac) {
        this.nombreUsuario = new SimpleStringProperty(nombreUsuario);
        this.contrasena = new SimpleStringProperty(contrasena);
        this.email = new SimpleStringProperty(email);
        this.fechaNac = fechaNac;
    }
    
    public void setNombreUsuario(String nombreUsuario) {
        this.nombreUsuario = new SimpleStringProperty(nombreUsuario);
    }
    
    public void setContrasena(String contrasena) {
        this.contrasena = new SimpleStringProperty(contrasena);
    }
    
    public void setEmail(String email) {
        this.email = new SimpleStringProperty(email);
    }
    
    public void setFechaNac(Date fechaNac) {
        this.fechaNac = fechaNac;
    }
    
    public String getNombreUsuario() {
        return nombreUsuario.get();
    }
    
    public String getContrasena() {
        return contrasena.get();
    }
    
    public String getEmail() {
        return email.get();
    }
    
    public Date getFechaNac() {
        return fechaNac;
    }
    
    public StringProperty nombreUsuarioProperty() {
        return nombreUsuario;
    }
    
    public StringProperty contrasenaProperty() {
        return contrasena;
    }
    
    public StringProperty emailProperty() {
        return email;
    }
    
}
