package entidades;

import javafx.beans.property.IntegerProperty;
import javafx.beans.property.SimpleIntegerProperty;

/**
 *
 * @author JatnielMartínez
 */
public class Marcador {
    
    private IntegerProperty jugadas;
    private IntegerProperty ganadas;
    private IntegerProperty perdidas;
    
    public Marcador() {
        
    }
    
    public Marcador(Integer jugadas, Integer ganadas, Integer perdidas) {
        this.jugadas = new SimpleIntegerProperty(jugadas);
        this.ganadas = new SimpleIntegerProperty(ganadas);
        this.perdidas = new SimpleIntegerProperty(perdidas);
    }
    
    public void setJugadas(Integer jugadas) {
        this.jugadas = new SimpleIntegerProperty(jugadas);
    }
    
    public void setGanadas(Integer ganadas) {
        this.ganadas = new SimpleIntegerProperty(ganadas);
    }
    
    public void setPerdidas(Integer perdidas) {
        this.perdidas = new SimpleIntegerProperty(perdidas);
    }
    
    public Integer getJugadas() {
        return jugadas.get();
    }
    
    public Integer getGanadas() {
        return ganadas.get();
    }
    
    public Integer getPerdidas() {
        return perdidas.get();
    }
    
    public IntegerProperty jugadasProperty() {
        return jugadas;
    }
    
    public IntegerProperty ganadasProperty() {
        return ganadas;
    }
    
    public IntegerProperty perdidasProperty() {
        return perdidas;
    }
    
}
