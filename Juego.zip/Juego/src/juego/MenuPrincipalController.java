package juego;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author cebal
 */
public class MenuPrincipalController implements Initializable {
    
    @FXML private Label lblElegir;
    @FXML private Button btnBuscar;
    @FXML private Button btnCrear;
    @FXML private Button btnMarcadores;
    @FXML private Button btnManual;
    @FXML private Button btnCambiar;
    @FXML private Button btnSalir;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lblElegir.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Elegir"));
        btnBuscar.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Buscar"));
        btnCrear.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Crear"));
        btnMarcadores.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Marcadores"));
        btnManual.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Manual"));
        btnCambiar.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Cambiar"));
        btnSalir.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Salir"));
        btnBuscar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Stage stage = (Stage) btnBuscar.getScene().getWindow();
                    stage.close();
                    ResourceBundle rb = ResourceBundle.getBundle("internacionalizacion.BuscarPartida");
                    FXMLLoader buscarPartida = new FXMLLoader(getClass().getResource("BuscarPartida.fxml"), rb);
                    Parent raiz = (Parent) buscarPartida.load();
                    stage.setScene(new Scene(raiz));
                    stage.show();
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    Alert alertDenegado = new Alert(Alert.AlertType.ERROR);
                    alertDenegado.setTitle("Error de JavaFX");
                    alertDenegado.setHeaderText(null);
                    alertDenegado.setContentText("Se produjo un error inesperado D:");
                    alertDenegado.showAndWait();
                }
            }
        });
        btnCrear.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Stage stage = (Stage) btnCrear.getScene().getWindow();
                    stage.close();
                    ResourceBundle rb = ResourceBundle.getBundle("internacionalizacion.CrearPartida");
                    FXMLLoader crearPartida = new FXMLLoader(getClass().getResource("CrearPartida.fxml"), rb);
                    Parent raiz = (Parent) crearPartida.load();
                    stage.setScene(new Scene(raiz));
                    stage.show();
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    Alert alertDenegado = new Alert(Alert.AlertType.ERROR);
                    alertDenegado.setTitle("Error de JavaFX");
                    alertDenegado.setHeaderText(null);
                    alertDenegado.setContentText("Se produjo un error inesperado D:");
                    alertDenegado.showAndWait();
                }
            }
        });
        btnMarcadores.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Stage stage = (Stage) btnMarcadores.getScene().getWindow();
                    stage.close();
                    ResourceBundle rb = ResourceBundle.getBundle("internacionalizacion.Marcadores");
                    FXMLLoader marcadores = new FXMLLoader(getClass().getResource("Marcadores.fxml"), rb);
                    Parent raiz = (Parent) marcadores.load();
                    stage.setScene(new Scene(raiz));
                    stage.show();
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    Alert alertDenegado = new Alert(Alert.AlertType.ERROR);
                    alertDenegado.setTitle("Error de JavaFX");
                    alertDenegado.setHeaderText(null);
                    alertDenegado.setContentText("Se produjo un error inesperado D:");
                    alertDenegado.showAndWait();
                }
            }
        });
        btnManual.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                System.out.println("Manual no disponible :'v");
            }
        });
        btnCambiar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Stage stage = (Stage) btnCambiar.getScene().getWindow();
                    stage.close();
                    ResourceBundle rb = ResourceBundle.getBundle("internacionalizacion.InicioSesion");
                    FXMLLoader inicioSesion = new FXMLLoader(getClass().getResource("FXMLDocument.fxml"), rb);
                    Parent raiz = (Parent) inicioSesion.load();
                    stage.setScene(new Scene(raiz));
                    stage.show();
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    Alert alertDenegado = new Alert(Alert.AlertType.ERROR);
                    alertDenegado.setTitle("Error de JavaFX");
                    alertDenegado.setHeaderText(null);
                    alertDenegado.setContentText("Se produjo un error inesperado D:");
                    alertDenegado.showAndWait();
                }
            }
        });
        btnSalir.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage stage = (Stage) btnSalir.getScene().getWindow();
                stage.close();
            }
        });
    }    
    
}
