package juego;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author cebal
 */
public class MenuPrincipalController implements Initializable {
    
    @FXML private Label lblElegir;
    @FXML private Button btnBuscar;
    @FXML private Button btnCrear;
    @FXML private Button btnMarcadores;
    @FXML private Button btnManual;
    @FXML private Button btnCambiar;
    @FXML private Button btnSalir;

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        lblElegir.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Elegir"));
        btnBuscar.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Buscar"));
        btnCrear.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Crear"));
        btnMarcadores.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Marcadores"));
        btnManual.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Manual"));
        btnCambiar.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Cambiar"));
        btnSalir.setText(ResourceBundle.getBundle("internacionalizacion.MenuPrincipal").getString("Salir"));
    }    
    
}
