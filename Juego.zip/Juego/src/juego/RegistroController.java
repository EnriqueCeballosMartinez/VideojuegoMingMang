package juego;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 *
 * @author JatnielMartinez
 */
public class RegistroController implements Initializable {
    
    @FXML private Label lblRegistrate;
    @FXML private Label lblUsuario;
    @FXML private Label lblEmail;
    @FXML private Label lblPassword;
    @FXML private Label lblVerificar;
    @FXML private Label lblEdad;
    @FXML private TextField txfUsuario;
    @FXML private TextField txfEmail;
    @FXML private PasswordField pwfPassword;
    @FXML private PasswordField pwfVerificar;
    @FXML private TextField txfEdad;
    @FXML private Button btnRegistrarse;
    @FXML private Button btnSalir;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lblRegistrate.setText(ResourceBundle.getBundle("internacionalizacion.Registro").getString("Registrate"));
        lblUsuario.setText(ResourceBundle.getBundle("internacionalizacion.Registro").getString("Usuario"));
        lblEmail.setText(ResourceBundle.getBundle("internacionalizacion.Registro").getString("Email"));
        lblPassword.setText(ResourceBundle.getBundle("internacionalizacion.Registro").getString("Password"));
        lblVerificar.setText(ResourceBundle.getBundle("internacionalizacion.Registro").getString("Verificar"));
        lblEdad.setText(ResourceBundle.getBundle("internacionalizacion.Registro").getString("Edad"));
        btnRegistrarse.setText(ResourceBundle.getBundle("internacionalizacion.Registro").getString("Registrarse"));
        btnSalir.setText(ResourceBundle.getBundle("internacionalizacion.Registro").getString("Salir"));
    }
    
}
