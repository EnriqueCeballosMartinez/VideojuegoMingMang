package juego;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Rectangle;

/**
 *
 * @author JatnielMartinez
 */
public class TableroController implements Initializable {
    
    @FXML private Label lblActual;
    @FXML private Label lblCampo;
    @FXML private Label lblReserva;
    @FXML private Label lblEnemigas;
    @FXML private Label lblTurno;
    @FXML private TextField txfActual;
    @FXML private TextField txfCampo;
    @FXML private TextField txfReserva;
    @FXML private TextField txfEnemigas;
    @FXML private TextField txfTurno;
    @FXML private Button btnPausa;
    @FXML private Button btnSalir;
    @FXML private GridPane gpTablero;
    @FXML private Rectangle rct0_0;
    @FXML private Rectangle rct0_1;
    @FXML private Rectangle rct0_2;
    @FXML private Rectangle rct0_3;
    @FXML private Rectangle rct0_4;
    @FXML private Rectangle rct0_5;
    @FXML private Rectangle rct0_6;
    @FXML private Rectangle rct0_7;
    @FXML private Rectangle rct1_0;
    @FXML private Rectangle rct1_1;
    @FXML private Rectangle rct1_2;
    @FXML private Rectangle rct1_3;
    @FXML private Rectangle rct1_4;
    @FXML private Rectangle rct1_5;
    @FXML private Rectangle rct1_6;
    @FXML private Rectangle rct1_7;
    @FXML private Rectangle rct2_0;
    @FXML private Rectangle rct2_1;
    @FXML private Rectangle rct2_2;
    @FXML private Rectangle rct2_3;
    @FXML private Rectangle rct2_4;
    @FXML private Rectangle rct2_5;
    @FXML private Rectangle rct2_6;
    @FXML private Rectangle rct2_7;
    @FXML private Rectangle rct3_0;
    @FXML private Rectangle rct3_1;
    @FXML private Rectangle rct3_2;
    @FXML private Rectangle rct3_3;
    @FXML private Rectangle rct3_4;
    @FXML private Rectangle rct3_5;
    @FXML private Rectangle rct3_6;
    @FXML private Rectangle rct3_7;
    @FXML private Rectangle rct4_0;
    @FXML private Rectangle rct4_1;
    @FXML private Rectangle rct4_2;
    @FXML private Rectangle rct4_3;
    @FXML private Rectangle rct4_4;
    @FXML private Rectangle rct4_5;
    @FXML private Rectangle rct4_6;
    @FXML private Rectangle rct4_7;
    @FXML private Rectangle rct5_0;
    @FXML private Rectangle rct5_1;
    @FXML private Rectangle rct5_2;
    @FXML private Rectangle rct5_3;
    @FXML private Rectangle rct5_4;
    @FXML private Rectangle rct5_5;
    @FXML private Rectangle rct5_6;
    @FXML private Rectangle rct5_7;
    @FXML private Rectangle rct6_0;
    @FXML private Rectangle rct6_1;
    @FXML private Rectangle rct6_2;
    @FXML private Rectangle rct6_3;
    @FXML private Rectangle rct6_4;
    @FXML private Rectangle rct6_5;
    @FXML private Rectangle rct6_6;
    @FXML private Rectangle rct6_7;
    @FXML private Rectangle rct7_0;
    @FXML private Rectangle rct7_1;
    @FXML private Rectangle rct7_2;
    @FXML private Rectangle rct7_3;
    @FXML private Rectangle rct7_4;
    @FXML private Rectangle rct7_5;
    @FXML private Rectangle rct7_6;
    @FXML private Rectangle rct7_7;
    @FXML private Circle cirBlanco00;
    @FXML private Circle cirBlanco01;
    @FXML private Circle cirBlanco02;
    @FXML private Circle cirBlanco03;
    @FXML private Circle cirBlanco04;
    @FXML private Circle cirBlanco05;
    @FXML private Circle cirBlanco06;
    @FXML private Circle cirBlanco07;
    @FXML private Circle cirBlanco08;
    @FXML private Circle cirBlanco09;
    @FXML private Circle cirBlanco10;
    @FXML private Circle cirBlanco11;
    @FXML private Circle cirBlanco12;
    @FXML private Circle cirBlanco13;
    @FXML private Circle cirNegro00;
    @FXML private Circle cirNegro01;
    @FXML private Circle cirNegro02;
    @FXML private Circle cirNegro03;
    @FXML private Circle cirNegro04;
    @FXML private Circle cirNegro05;
    @FXML private Circle cirNegro06;
    @FXML private Circle cirNegro07;
    @FXML private Circle cirNegro08;
    @FXML private Circle cirNegro09;
    @FXML private Circle cirNegro10;
    @FXML private Circle cirNegro11;
    @FXML private Circle cirNegro12;
    @FXML private Circle cirNegro13;
    private Locale l;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        l = Locale.getDefault();
        resources = ResourceBundle.getBundle("internacionalizacion.Tablero");
        lblActual.setText(resources.getString("Actual"));
        lblCampo.setText(resources.getString("Campo"));
        lblReserva.setText(resources.getString("Reserva"));
        lblEnemigas.setText(resources.getString("Enemigas"));
        lblTurno.setText(resources.getString("Turno"));
        btnPausa.setText(resources.getString("Pausa"));
        btnSalir.setText(resources.getString("Salir"));
    }
    
}
