/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juego;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author cebal
 */
public class FXMLDocumentController implements Initializable {

    @FXML private Label lbBienvenida;
    @FXML private Label lbUsuario;
    @FXML private Label lbPassword;
    @FXML private Button btIngresar;
    @FXML private Button btSalir;
    @FXML private Label lbCuenta;
    @FXML private Hyperlink hpRegistrarse;
    private ResourceBundle resbou;
    private Locale l;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       l = new Locale("es");
       resbou = ResourceBundle.getBundle("internacionalizacion.InicioSesion", l);
       lbBienvenida.setText(resbou.getString("%Bienvenida"));
       lbUsuario.setText(resbou.getString("%Usuario"));
       lbPassword.setText(resbou.getString("%Password"));
       btIngresar.setText(resbou.getString("%Ingresar"));
       btSalir.setText(resbou.getString("%Salir"));
       lbCuenta.setText(resbou.getString("%Cuenta"));
       hpRegistrarse.setText(resbou.getString("%Registrate"));
    }    

    @FXML
    private void handleButtonAction(ActionEvent event) {
    }
    
}
