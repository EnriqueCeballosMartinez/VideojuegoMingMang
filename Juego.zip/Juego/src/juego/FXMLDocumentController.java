/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juego;

import java.net.URL;
import java.util.Locale;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;

/**
 * FXML Controller class
 *
 * @author cebal
 */
public class FXMLDocumentController implements Initializable {

    @FXML private Label lbBienvenida;
    @FXML private Label lbUsuario;
    @FXML private Label lbPassword;
    @FXML private Button btIngresar;
    @FXML private Button btSalir;
    @FXML private Label lbCuenta;
    @FXML private Hyperlink hpRegistrarse;
    //private Locale l;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       lbBienvenida.setText(rb.getString("%Bienvenida"));
       lbUsuario.setText(rb.getString("%Usuario"));
       lbPassword.setText(rb.getString("%Password"));
       btIngresar.setText(rb.getString("%Ingresar"));
       btSalir.setText(rb.getString("%Salir"));
       lbCuenta.setText(rb.getString("%Cuenta"));
       hpRegistrarse.setText(rb.getString("%Registrate"));
    }    

    @FXML
    private void handleButtonAction(ActionEvent event) {
    }
    
}
