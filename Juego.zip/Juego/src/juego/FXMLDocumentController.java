/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package juego;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.Hyperlink;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author cebal
 */
public class FXMLDocumentController implements Initializable {

    @FXML private Label lbBienvenida;
    @FXML private Label lbUsuario;
    @FXML private TextField tfUsuario;
    @FXML private Label lbPassword;
    @FXML private PasswordField pfPassword;
    @FXML private Button btIngresar;
    @FXML private Button btSalir;
    @FXML private Label lbCuenta;
    @FXML private Hyperlink hpRegistrarse;

    /**
     * Initializes the controller class.
     * @param url
     * @param rb
     */
    @Override
    @SuppressWarnings("Convert2Lambda")
    public void initialize(URL url, ResourceBundle rb) {
        lbBienvenida.setText(ResourceBundle.getBundle("internacionalizacion.InicioSesion").getString("Bienvenida"));
        lbUsuario.setText(ResourceBundle.getBundle("internacionalizacion.InicioSesion").getString("Usuario"));
        lbPassword.setText(ResourceBundle.getBundle("internacionalizacion.InicioSesion").getString("Password"));
        btIngresar.setText(ResourceBundle.getBundle("internacionalizacion.InicioSesion").getString("Ingresar"));
        btSalir.setText(ResourceBundle.getBundle("internacionalizacion.InicioSesion").getString("Salir"));
        lbCuenta.setText(ResourceBundle.getBundle("internacionalizacion.InicioSesion").getString("Cuenta"));
        hpRegistrarse.setText(ResourceBundle.getBundle("internacionalizacion.InicioSesion").getString("Registrate"));
        btIngresar.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                validar(tfUsuario, pfPassword);
            }
        });
        btSalir.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                Stage stage = (Stage) btSalir.getScene().getWindow();
                stage.close();
            }
        });
        hpRegistrarse.setOnAction(new EventHandler<ActionEvent>() {
            @Override
            public void handle(ActionEvent event) {
                try {
                    Stage stage = (Stage) hpRegistrarse.getScene().getWindow();
                    stage.close();
                    ResourceBundle rb = ResourceBundle.getBundle("internacionalizacion.Registro");
                    FXMLLoader registro = new FXMLLoader(getClass().getResource("Registro.fxml"), rb);
                    Parent raiz = (Parent) registro.load();
                    stage.setScene(new Scene(raiz));
                    stage.show();
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    Alert alertDenegado = new Alert(AlertType.ERROR);
                    alertDenegado.setTitle("Error de JavaFX");
                    alertDenegado.setHeaderText(null);
                    alertDenegado.setContentText("Se produjo un error inesperado D:");
                    alertDenegado.showAndWait();
                }
            }
        });
    }
    
    public void validar(TextField tf, PasswordField pf) {
        if (!tf.getText().isEmpty() && !pf.getText().isEmpty()) {
            if (tf.getText().equals("ColaMartinsson") && pf.getText().equals("123456")) {
                try {
                    Stage stage = (Stage) btIngresar.getScene().getWindow();
                    stage.close();
                    ResourceBundle rb = ResourceBundle.getBundle("internacionalizacion.MenuPrincipal");
                    FXMLLoader menuPrincipal = new FXMLLoader(getClass().getResource("MenuPrincipal.fxml"), rb);
                    Parent raiz = (Parent) menuPrincipal.load();
                    stage.setScene(new Scene(raiz));
                    stage.show();
                } catch (IOException ex) {
                    Logger.getLogger(FXMLDocumentController.class.getName()).log(Level.SEVERE, null, ex);
                    Alert alertDenegado = new Alert(AlertType.ERROR);
                    alertDenegado.setTitle("Error de JavaFX");
                    alertDenegado.setHeaderText(null);
                    alertDenegado.setContentText("Se produjo un error inesperado D:");
                    alertDenegado.showAndWait();
                }
            } else {
                Alert alertIncorrecto = new Alert(AlertType.WARNING);
                alertIncorrecto.setTitle("Acceso denegado");
                alertIncorrecto.setHeaderText(null);
                alertIncorrecto.setContentText("Los datos ingresados no son los correctos :v");
                alertIncorrecto.showAndWait();
            }
         } else {
            Alert alertVacio = new Alert(AlertType.WARNING);
            alertVacio.setTitle("Acceso denegado");
            alertVacio.setHeaderText(null);
            alertVacio.setContentText("No puede dejar los campos vacíos >:v");
            alertVacio.showAndWait();
        }
    }

}
