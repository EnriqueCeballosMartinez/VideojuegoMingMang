package juego;

import entidades.Jugador;
import entidades.Marcador;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author JatnielMartinez
 */
public class MarcadoresController implements Initializable {
    
    @FXML private Label lblMejores;
    @FXML private TableView tblMarcadores;
    @FXML private TableColumn<Marcador, Integer> colPuesto;
    @FXML private TableColumn<Marcador, Jugador> colUsuario;
    @FXML private TableColumn<Marcador, Integer> colTotal;
    @FXML private TableColumn<Marcador, Integer> colGanadas;
    @FXML private TableColumn<Marcador, Integer> colPerdidas;
    @FXML private Button btnSalir;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lblMejores.setText(ResourceBundle.getBundle("internacionalizacion.Marcadores").getString("Mejores"));
        colPuesto.setText(ResourceBundle.getBundle("internacionalizacion.Marcadores").getString("Puesto"));
        colUsuario.setText(ResourceBundle.getBundle("internacionalizacion.Marcadores").getString("Usuario"));
        colTotal.setText(ResourceBundle.getBundle("internacionalizacion.Marcadores").getString("Total"));
        colGanadas.setText(ResourceBundle.getBundle("internacionalizacion.Marcadores").getString("Ganadas"));
        colPerdidas.setText(ResourceBundle.getBundle("internacionalizacion.Marcadores").getString("Perdidas"));
        btnSalir.setText(ResourceBundle.getBundle("internacionalizacion.Marcadores").getString("Salir"));
    }
    
}
