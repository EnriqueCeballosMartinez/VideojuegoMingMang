package juego;

import entidades.Jugador;
import entidades.Marcador;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author JatnielMartinez
 */
public class MarcadoresController implements Initializable {
    
    @FXML private Label lblMejores;
    @FXML private TableView tblMarcadores;
    @FXML private TableColumn<Marcador, Integer> colPuesto;
    @FXML private TableColumn<Marcador, Jugador> colUsuario;
    @FXML private TableColumn<Marcador, Integer> colTotal;
    @FXML private TableColumn<Marcador, Integer> colGanadas;
    @FXML private TableColumn<Marcador, Integer> colPerdidas;
    @FXML private Button btnSalir;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        resources = ResourceBundle.getBundle("internacionalizacion.Marcadores");
        lblMejores.setText(resources.getString("Mejores"));
        colPuesto.setText(resources.getString("Puesto"));
        colUsuario.setText(resources.getString("Usuario"));
        colTotal.setText(resources.getString("Total"));
        colGanadas.setText(resources.getString("Ganadas"));
        colPerdidas.setText(resources.getString("Perdidas"));
        btnSalir.setText(resources.getString("Salir"));
    }
    
}
