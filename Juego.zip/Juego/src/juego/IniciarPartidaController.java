package juego;

import entidades.Juego;
import entidades.Jugador;
import entidades.Partida;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author JatnielMartinez
 */
public class IniciarPartidaController implements Initializable {
    
    @FXML private TableView tblJugadores;
    @FXML private TableColumn<Juego, Jugador> colUsuario;
    @FXML private TableColumn<Juego, String> colColor;
    @FXML private TableColumn<Juego, Partida> colEstado;
    @FXML private Label lblPresiona;
    @FXML private Button btnListo;
    @FXML private Button btnComenzar;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        colUsuario.setText(ResourceBundle.getBundle("internacionalizacion.IniciarPartida").getString("Usuario"));
        colColor.setText(ResourceBundle.getBundle("internacionalizacion.IniciarPartida").getString("Color"));
        colEstado.setText(ResourceBundle.getBundle("internacionalizacion.IniciarPartida").getString("Estado"));
        lblPresiona.setText(ResourceBundle.getBundle("internacionalizacion.IniciarPartida").getString("Presiona"));
        btnListo.setText(ResourceBundle.getBundle("internacionalizacion.IniciarPartida").getString("Listo"));
        btnComenzar.setText(ResourceBundle.getBundle("internacionalizacion.IniciarPartida").getString("Comenzar"));
    }
    
}
