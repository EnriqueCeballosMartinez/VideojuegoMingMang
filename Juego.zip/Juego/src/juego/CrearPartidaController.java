package juego;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;

/**
 *
 * @author JatnielMartinez
 */
public class CrearPartidaController implements Initializable {
    
    @FXML private Label lblInstruccion;
    @FXML private Label lblNombrePartida;
    @FXML private TextField txfNombrePartida;
    @FXML private Label lblHabilitar;
    @FXML private RadioButton rdbSi;
    @FXML private RadioButton rdbNo;
    @FXML private Label lblContrasena;
    @FXML private PasswordField pwfContrasena;
    @FXML private Button btnCrear;
    @FXML private Button btnSalir;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lblInstruccion.setText(ResourceBundle.getBundle("internacionalizacion.CrearPartida").getString("Instruccion"));
        lblNombrePartida.setText(ResourceBundle.getBundle("internacionalizacion.CrearPartida").getString("NombrePartida"));
        lblHabilitar.setText(ResourceBundle.getBundle("internacionalizacion.CrearPartida").getString("Habilitar"));
        rdbSi.setText(ResourceBundle.getBundle("internacionalizacion.CrearPartida").getString("Si"));
        rdbNo.setText(ResourceBundle.getBundle("internacionalizacion.CrearPartida").getString("No"));
        lblContrasena.setText(ResourceBundle.getBundle("internacionalizacion.CrearPartida").getString("Contrasena"));
        btnCrear.setText(ResourceBundle.getBundle("internacionalizacion.CrearPartida").getString("Crear"));
        btnSalir.setText(ResourceBundle.getBundle("internacionalizacion.CrearPartida").getString("Salir"));
    }
    
}
