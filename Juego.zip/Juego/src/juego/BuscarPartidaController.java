package juego;

import entidades.Jugador;
import entidades.Partida;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author JatnielMartinez
 */
public class BuscarPartidaController implements Initializable {
    
    @FXML private Label lblPartida;
    @FXML private TableView tblPartidas;
    @FXML private Label lblPregunta;
    @FXML private Button btnIngresar;
    @FXML private Button btnVolver;
    @FXML private Button btnCrear;
    @FXML private TableColumn<Partida,String> colNombrePartida;
    @FXML private TableColumn<Partida,Jugador> colUsuario;
    @FXML private TableColumn<Partida,String> colDisponibilidad;
    @FXML private TableColumn<Partida,String> colContrasena;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        resources = ResourceBundle.getBundle("internacionalizacion.BuscarPartida");
        lblPartida.setText(resources.getString("Partida"));
        lblPregunta.setText(resources.getString("Pregunta"));
        btnIngresar.setText(resources.getString("Ingresar"));
        btnVolver.setText(resources.getString("Volver"));
        btnCrear.setText(resources.getString("Crear"));
        colNombrePartida.setText(resources.getString("NombrePartida"));
        colUsuario.setText(resources.getString("Usuario"));
        colDisponibilidad.setText(resources.getString("Disponibilidad"));
        colContrasena.setText(resources.getString("Contrasena"));
    }
    
}
