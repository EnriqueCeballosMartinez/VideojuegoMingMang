package juego;

import entidades.Jugador;
import entidades.Partida;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

/**
 *
 * @author JatnielMartinez
 */
public class BuscarPartidaController implements Initializable {
    
    @FXML private Label lblPartida;
    @FXML private TableView tblPartidas;
    @FXML private Label lblPregunta;
    @FXML private Button btnIngresar;
    @FXML private Button btnVolver;
    @FXML private Button btnCrear;
    @FXML private TableColumn<Partida,String> colNombrePartida;
    @FXML private TableColumn<Partida,Jugador> colUsuario;
    @FXML private TableColumn<Partida,String> colDisponibilidad;
    @FXML private TableColumn<Partida,String> colContrasena;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        lblPartida.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("Partida"));
        lblPregunta.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("Pregunta"));
        btnIngresar.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("Ingresar"));
        btnVolver.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("Volver"));
        btnCrear.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("Crear"));
        colNombrePartida.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("NombrePartida"));
        colUsuario.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("Usuario"));
        colDisponibilidad.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("Disponibilidad"));
        colContrasena.setText(ResourceBundle.getBundle("internacionalizacion.BuscarPartida").getString("Contrasena"));
    }
    
}
